# -*- coding: utf-8 -*-
#################################################################################
# Author      : Webkul Software Pvt. Ltd. (<https://webkul.com/>)
# Copyright(c): 2015-Present Webkul Software Pvt. Ltd.
# License URL : https://store.webkul.com/license.html/
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>
#################################################################################

from . import patho_test_request
from . import patho_source
from . import patho_res_partner
from . import inherit_product_template
from . import patho_test_report
from . import patho_lab_test_unit
from . import patho_test_criteria
from . import patho_test_parameters
from . import patho_lab_centers
from . import patho_config_settings
from . import inherit_sale
